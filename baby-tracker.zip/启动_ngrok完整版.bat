@echo off
chcp 65001 >nul
echo.
echo  🍼 宝宝成长记录 (ngrok) - 启动中...
echo  ════════════════════════════
echo.

cd /d "%~dp0"

REM 配置 ngrok authtoken
echo  正在配置 ngrok...
ngrok config add-authtoken 3Ea63ySi0IfaCjveE8EmLZsVQf9_7pwzyD8DXtsJJx7qzaWAY

REM 启动 Node.js HTTP 服务器
start /min "宝宝服务器" node "C:\Users\admin\.trae-cn\work\6a1d3b6db275241dbe05cc92\server.js"

REM 等 2 秒
TIMEOUT /T 2 /NOBREAK >nul

REM 启动 ngrok
echo  正在启动 ngrok 隧道...
start "ngrok隧道" ngrok http 8080

echo.
echo  ✅ 服务已启动！
echo  📱 访问地址请查看 ngrok 窗口（https://xxx.ngrok-free.app）
echo.
pause
