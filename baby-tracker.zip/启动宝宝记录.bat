@echo off
chcp 65001 >nul
echo.
echo  🍼 宝宝成长记录 - 启动中...
echo  ══════════════════════════
echo.

cd /d "%~dp0"

REM 启动 Node.js HTTP 服务器（后台）
start /min "宝宝服务器" node "C:\Users\admin\.trae-cn\work\6a1d3b6db275241dbe05cc92\server.js"

REM 等 2 秒让服务器先起来
timeout /t 2 /nobreak >nul

REM 启动 localtunnel
start /min "localtunnel" cmd /c "lt --port 8080 --subdomain baby-tracker-family"

echo.
echo  ✅ 服务已启动！
echo  📱 当 subdomain 被占用时会换新链接，看 locatunnel 窗口
echo.
pause
